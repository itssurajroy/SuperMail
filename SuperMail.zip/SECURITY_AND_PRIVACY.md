# Security & Privacy Notes

- No secrets are committed.
- OAuth credentials must be stored in environment variables.
