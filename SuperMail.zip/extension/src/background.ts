// Background service worker
console.log('SuperMail background running');
