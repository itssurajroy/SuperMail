# SuperMail

Production-ready Chrome Extension (Manifest V3) with Node.js + TypeScript backend.
